﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace TicketReservationSystem
{
    public partial class frmBooking : Form
    {
        private readonly string connectionString =
     @"Data Source=(LocalDB)\MSSQLLocalDB;
      AttachDbFilename=C:\Users\Rupok\Pictures\TicketReservationSystem\TicketReservationSystem\Event.mdf;
      Integrated Security=True;";

        private int eventId;
        private decimal pricePerSeat;
        private int seatsAvailable;

        public frmBooking()
        {
            InitializeComponent();
            this.Load += frmBooking_Load;
        }

        public frmBooking(int selectedEventId) : this()
        {
            eventId = selectedEventId;
        }

        private void frmBooking_Load(object sender, EventArgs e)
        {
            LoadEventInformation();
        }

        /// <summary>
        /// Fetches full event information for the chosen event.
        /// </summary>
        private void LoadEventInformation()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlDataAdapter adapter = new SqlDataAdapter(
                    "SELECT * FROM Events WHERE EventID = @eventId", conn))
                {
                    adapter.SelectCommand.Parameters.AddWithValue("@eventId", eventId);

                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show(
                            "The selected event could not be located.",
                            "Event Not Found",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        Close();
                        return;
                    }

                    dgvEvents.DataSource = dt;
                    dgvEvents.ReadOnly = true;
                    dgvEvents.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    dgvEvents.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    DataRow row = dt.Rows[0];

                    string title = row["Title"].ToString();
                    this.Text = "Booking – " + title;

                    pricePerSeat = Convert.ToDecimal(row["Price"]);
                    seatsAvailable = Convert.ToInt32(row["SeatsAvailable"]);

                    txtTotalCost.Text = 0m.ToString("C");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Unable to retrieve event details.\n\n" + ex.Message,
                    "Load Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Processes booking and updates event availability.
        /// </summary>
        private void btnCheckout_Click(object sender, EventArgs e)
        {
            // Required field validation
            if (string.IsNullOrWhiteSpace(txtFirstName.Text) ||
                string.IsNullOrWhiteSpace(txtLastName.Text) ||
                string.IsNullOrWhiteSpace(txtAddress.Text) ||
                string.IsNullOrWhiteSpace(txtPhoneNum.Text) ||
                string.IsNullOrWhiteSpace(txtSeatNum.Text) ||
                string.IsNullOrWhiteSpace(txtCardNum.Text))
            {
                MessageBox.Show(
                    "Please ensure all booking fields are completed.",
                    "Incomplete Information",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            // Name validation
            if (txtFirstName.Text.Any(char.IsDigit) || txtLastName.Text.Any(char.IsDigit))
            {
                MessageBox.Show(
                    "Names should contain alphabetic characters only.",
                    "Invalid Name Format",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            // Phone validation
            if (!txtPhoneNum.Text.All(char.IsDigit) || txtPhoneNum.Text.Length != 10)
            {
                MessageBox.Show(
                    "The phone number must include exactly 10 digits.",
                    "Invalid Phone Number",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            // Card validation
            if (!txtCardNum.Text.All(char.IsDigit) || txtCardNum.Text.Length != 16)
            {
                MessageBox.Show(
                    "Enter a valid 16-digit credit card number.",
                    "Invalid Card Number",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            // Seat quantity validation
            if (!int.TryParse(txtSeatNum.Text, out int seatsRequested) || seatsRequested <= 0)
            {
                MessageBox.Show(
                    "Please enter a positive number of seats.",
                    "Invalid Seat Quantity",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (seatsRequested > seatsAvailable)
            {
                MessageBox.Show(
                    "The number of seats requested exceeds current availability.",
                    "Insufficient Seats",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            decimal totalCost = pricePerSeat * seatsRequested;
            txtTotalCost.Text = totalCost.ToString("C");

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(
                    "UPDATE Events SET SeatsAvailable = SeatsAvailable - @qty, SeatsSold = SeatsSold + @qty WHERE EventID = @eventId",
                    conn))
                {
                    cmd.Parameters.AddWithValue("@qty", seatsRequested);
                    cmd.Parameters.AddWithValue("@eventId", eventId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                string customerName = $"{txtFirstName.Text.Trim()} {txtLastName.Text.Trim()}";

                MessageBox.Show(
                    "Your reservation has been successfully processed!\n\n" +
                    $"Customer: {customerName}\n" +
                    $"Event ID: {eventId}\n" +
                    $"Amount Paid: {totalCost:C}",
                    "Booking Confirmed",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                Application.Exit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An error occurred while finalizing your booking.\n\n" + ex.Message,
                    "Transaction Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtSeatNum_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
