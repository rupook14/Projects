﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace TicketReservationSystem
{
    public partial class frmEvents : Form
    {
        private readonly string connectionString =
    @"Data Source=(LocalDB)\MSSQLLocalDB;
      AttachDbFilename=C:\Users\Rupok\Pictures\TicketReservationSystem\TicketReservationSystem\Event.mdf;
      Integrated Security=True;";

        private DataTable eventsTable;

        public frmEvents()
        {
            InitializeComponent();
        }

        private void frmEvents_Load(object sender, EventArgs e)
        {
            LoadEventsFromDatabase();
        }

        /// <summary>
        /// Retrieves all event records and places them into the DataGridView.
        /// </summary>
        private void LoadEventsFromDatabase()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Events", conn))
                {
                    eventsTable = new DataTable();
                    adapter.Fill(eventsTable);

                    dgvEvents.DataSource = eventsTable;

                    dgvEvents.ReadOnly = true;
                    dgvEvents.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    dgvEvents.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Unable to load event listings. Please verify your database connection.\n\n" + ex.Message,
                    "Loading Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // PictureBox event triggers
        private void pbEvent1_Click(object sender, EventArgs e)
        {
            OpenEventBookingForm(1);
        }

        private void pbEvent2_Click(object sender, EventArgs e)
        {
            OpenEventBookingForm(2);
        }

        private void pbEvent3_Click(object sender, EventArgs e)
        {
            OpenEventBookingForm(3);
        }

        private void pbEvent4_Click(object sender, EventArgs e)
        {
            OpenEventBookingForm(4);
        }

        /// <summary>
        /// Launches the booking screen for the chosen event.
        /// </summary>
        private void OpenEventBookingForm(int eventId)
        {
            HighlightSelectedEvent(eventId);

            frmBooking booking = new frmBooking(eventId);
            booking.ShowDialog();
        }

        /// <summary>
        /// Highlights the row in the table that corresponds to the selected event.
        /// </summary>
        private void HighlightSelectedEvent(int eventId)
        {
            if (dgvEvents.DataSource == null)
                return;

            foreach (DataGridViewRow row in dgvEvents.Rows)
            {
                if (row.Cells["EventID"].Value == null)
                    continue;

                int id = Convert.ToInt32(row.Cells["EventID"].Value);

                if (id == eventId)
                {
                    row.Selected = true;
                    dgvEvents.CurrentCell = row.Cells[0];
                    break;
                }
            }
        }

        private void lblEvent4_Click(object sender, EventArgs e)
        {

        }
    }
}
