﻿IF OBJECT_ID('dbo.Events', 'U') IS NOT NULL
    DROP TABLE dbo.Events;
GO


CREATE TABLE dbo.Events
(
    EventID INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(150)       NOT NULL,
    Location NVARCHAR(250)    NOT NULL,
    EventDateTime DATETIME    NOT NULL,
    Price DECIMAL(10,2)       NOT NULL,
    SeatsAvailable INT        NOT NULL,
    SeatsSold INT             NOT NULL DEFAULT 0
);
GO


INSERT INTO dbo.Events
    (Title, Location, EventDateTime, Price, SeatsAvailable, SeatsSold)
VALUES
    -- Music / Festival Event
    ('Skyline Rhythm Festival',
     'Harbourfront Grounds, Toronto',
     DATEADD(DAY, 7, GETDATE()),
     72.99,
     150,
     0),

    -- Movie / Special Screening
    ('Galactic Frontier: Special Early Screening',
     'SilverDome Cinema – Hall 3',
     DATEADD(DAY, 12, GETDATE()),
     19.00,
     180,
     0),

    -- Luxury Travel Package
    ('Seychelles Ocean Bliss Retreat',
     'Azure Travel Agency – Main Office',
     DATEADD(DAY, 30, GETDATE()),
     1699.00,
     25,
     0),

    -- Mountain Expedition Event
    ('Alpine Ridge Expedition Tour',
     'Rocky Crest Visitor Centre, Colorado',
     DATEADD(DAY, 18, GETDATE()),
     449.50,
     40,
     0);
GO
