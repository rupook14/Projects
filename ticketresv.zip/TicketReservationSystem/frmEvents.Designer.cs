﻿namespace TicketReservationSystem
{
    partial class frmEvents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEvents));
            this.lblInstruction = new System.Windows.Forms.Label();
            this.pbEvent1 = new System.Windows.Forms.PictureBox();
            this.pbEvent3 = new System.Windows.Forms.PictureBox();
            this.pbEvent4 = new System.Windows.Forms.PictureBox();
            this.pbEvent2 = new System.Windows.Forms.PictureBox();
            this.lblEvent1 = new System.Windows.Forms.Label();
            this.lblEvent2 = new System.Windows.Forms.Label();
            this.lblEvent3 = new System.Windows.Forms.Label();
            this.lblEvent4 = new System.Windows.Forms.Label();
            this.dgvEvents = new System.Windows.Forms.DataGridView();
            this.pnlOrganiz = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pbEvent1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEvent3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEvent4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEvent2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEvents)).BeginInit();
            this.pnlOrganiz.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblInstruction
            // 
            this.lblInstruction.AutoSize = true;
            this.lblInstruction.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstruction.Location = new System.Drawing.Point(254, 9);
            this.lblInstruction.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblInstruction.Name = "lblInstruction";
            this.lblInstruction.Size = new System.Drawing.Size(296, 20);
            this.lblInstruction.TabIndex = 0;
            this.lblInstruction.Text = "Please select the picture u want tickets for.";
            this.lblInstruction.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbEvent1
            // 
            this.pbEvent1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbEvent1.Image = ((System.Drawing.Image)(resources.GetObject("pbEvent1.Image")));
            this.pbEvent1.Location = new System.Drawing.Point(11, 12);
            this.pbEvent1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pbEvent1.Name = "pbEvent1";
            this.pbEvent1.Size = new System.Drawing.Size(188, 263);
            this.pbEvent1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEvent1.TabIndex = 1;
            this.pbEvent1.TabStop = false;
            this.pbEvent1.Click += new System.EventHandler(this.pbEvent1_Click);
            // 
            // pbEvent3
            // 
            this.pbEvent3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbEvent3.Image = ((System.Drawing.Image)(resources.GetObject("pbEvent3.Image")));
            this.pbEvent3.Location = new System.Drawing.Point(411, 12);
            this.pbEvent3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pbEvent3.Name = "pbEvent3";
            this.pbEvent3.Size = new System.Drawing.Size(188, 263);
            this.pbEvent3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEvent3.TabIndex = 2;
            this.pbEvent3.TabStop = false;
            this.pbEvent3.Click += new System.EventHandler(this.pbEvent3_Click);
            // 
            // pbEvent4
            // 
            this.pbEvent4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbEvent4.Image = ((System.Drawing.Image)(resources.GetObject("pbEvent4.Image")));
            this.pbEvent4.Location = new System.Drawing.Point(613, 12);
            this.pbEvent4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pbEvent4.Name = "pbEvent4";
            this.pbEvent4.Size = new System.Drawing.Size(188, 263);
            this.pbEvent4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEvent4.TabIndex = 3;
            this.pbEvent4.TabStop = false;
            this.pbEvent4.Click += new System.EventHandler(this.pbEvent4_Click);
            // 
            // pbEvent2
            // 
            this.pbEvent2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbEvent2.Image = ((System.Drawing.Image)(resources.GetObject("pbEvent2.Image")));
            this.pbEvent2.Location = new System.Drawing.Point(209, 12);
            this.pbEvent2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pbEvent2.Name = "pbEvent2";
            this.pbEvent2.Size = new System.Drawing.Size(188, 263);
            this.pbEvent2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEvent2.TabIndex = 4;
            this.pbEvent2.TabStop = false;
            this.pbEvent2.Click += new System.EventHandler(this.pbEvent2_Click);
            // 
            // lblEvent1
            // 
            this.lblEvent1.AutoSize = true;
            this.lblEvent1.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEvent1.Location = new System.Drawing.Point(64, 285);
            this.lblEvent1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEvent1.Name = "lblEvent1";
            this.lblEvent1.Size = new System.Drawing.Size(58, 20);
            this.lblEvent1.TabIndex = 5;
            this.lblEvent1.Text = "Skyline";
            // 
            // lblEvent2
            // 
            this.lblEvent2.AutoSize = true;
            this.lblEvent2.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEvent2.Location = new System.Drawing.Point(245, 285);
            this.lblEvent2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEvent2.Name = "lblEvent2";
            this.lblEvent2.Size = new System.Drawing.Size(121, 20);
            this.lblEvent2.TabIndex = 6;
            this.lblEvent2.Text = "Galactic Frontier";
            // 
            // lblEvent3
            // 
            this.lblEvent3.AutoSize = true;
            this.lblEvent3.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEvent3.Location = new System.Drawing.Point(407, 285);
            this.lblEvent3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEvent3.Name = "lblEvent3";
            this.lblEvent3.Size = new System.Drawing.Size(159, 20);
            this.lblEvent3.TabIndex = 7;
            this.lblEvent3.Text = "Seychelles Ocean Bliss";
            // 
            // lblEvent4
            // 
            this.lblEvent4.AutoSize = true;
            this.lblEvent4.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEvent4.Location = new System.Drawing.Point(609, 285);
            this.lblEvent4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEvent4.Name = "lblEvent4";
            this.lblEvent4.Size = new System.Drawing.Size(173, 20);
            this.lblEvent4.TabIndex = 8;
            this.lblEvent4.Text = "Alpine Ridge Expedition";
            this.lblEvent4.Click += new System.EventHandler(this.lblEvent4_Click);
            // 
            // dgvEvents
            // 
            this.dgvEvents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEvents.Location = new System.Drawing.Point(258, 51);
            this.dgvEvents.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvEvents.Name = "dgvEvents";
            this.dgvEvents.RowHeadersWidth = 62;
            this.dgvEvents.RowTemplate.Height = 28;
            this.dgvEvents.Size = new System.Drawing.Size(328, 146);
            this.dgvEvents.TabIndex = 9;
            // 
            // pnlOrganiz
            // 
            this.pnlOrganiz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlOrganiz.Controls.Add(this.lblEvent4);
            this.pnlOrganiz.Controls.Add(this.pbEvent4);
            this.pnlOrganiz.Controls.Add(this.lblEvent1);
            this.pnlOrganiz.Controls.Add(this.lblEvent2);
            this.pnlOrganiz.Controls.Add(this.lblEvent3);
            this.pnlOrganiz.Controls.Add(this.pbEvent3);
            this.pnlOrganiz.Controls.Add(this.pbEvent1);
            this.pnlOrganiz.Controls.Add(this.pbEvent2);
            this.pnlOrganiz.Location = new System.Drawing.Point(8, 207);
            this.pnlOrganiz.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pnlOrganiz.Name = "pnlOrganiz";
            this.pnlOrganiz.Size = new System.Drawing.Size(827, 318);
            this.pnlOrganiz.TabIndex = 10;
            // 
            // frmEvents
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(847, 536);
            this.Controls.Add(this.pnlOrganiz);
            this.Controls.Add(this.dgvEvents);
            this.Controls.Add(this.lblInstruction);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MinimizeBox = false;
            this.Name = "frmEvents";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Events Detail";
            this.Load += new System.EventHandler(this.frmEvents_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbEvent1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEvent3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEvent4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEvent2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEvents)).EndInit();
            this.pnlOrganiz.ResumeLayout(false);
            this.pnlOrganiz.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInstruction;
        private System.Windows.Forms.PictureBox pbEvent1;
        private System.Windows.Forms.PictureBox pbEvent3;
        private System.Windows.Forms.PictureBox pbEvent4;
        private System.Windows.Forms.PictureBox pbEvent2;
        private System.Windows.Forms.Label lblEvent1;
        private System.Windows.Forms.Label lblEvent2;
        private System.Windows.Forms.Label lblEvent3;
        private System.Windows.Forms.Label lblEvent4;
        private System.Windows.Forms.DataGridView dgvEvents;
        private System.Windows.Forms.Panel pnlOrganiz;
    }
}

